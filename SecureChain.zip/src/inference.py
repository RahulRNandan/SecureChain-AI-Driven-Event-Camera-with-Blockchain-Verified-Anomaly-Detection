# TODO: Implement Inference functionality
